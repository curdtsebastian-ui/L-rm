package ch.laermprotokoll.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class NoiseEvent(
    val start: Long,
    val end: Long,
    val averageDb: Double,
    val peakDb: Double,
    val label: String = "Lärmereignis",
    val confidence: Double = 0.0
)

object NoiseEventStore {
    private const val PREFS = "noise_events"
    private const val KEY = "events"
    private val events = mutableListOf<NoiseEvent>()
    private var loaded = false

    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            events.add(
                NoiseEvent(
                    o.getLong("start"),
                    o.getLong("end"),
                    o.getDouble("average"),
                    o.getDouble("peak"),
                    o.optString("label", "Lärmereignis"),
                    o.optDouble("confidence", 0.0)
                )
            )
        }
        loaded = true
    }

    @Synchronized
    fun add(
        context: Context,
        start: Long,
        end: Long,
        averageDb: Double,
        peakDb: Double,
        label: String = "Lärmereignis",
        confidence: Double = 0.0
    ) {
        init(context)
        events.add(0, NoiseEvent(start, end, averageDb, peakDb, label, confidence))
        save(context)
    }

    @Synchronized
    fun all(context: Context): List<NoiseEvent> {
        init(context)
        return events.toList()
    }

    @Synchronized
    fun clear(context: Context) {
        events.clear()
        save(context)
    }

    private fun save(context: Context) {
        val arr = JSONArray()
        events.forEach {
            arr.put(JSONObject().apply {
                put("start", it.start)
                put("end", it.end)
                put("average", it.averageDb)
                put("peak", it.peakDb)
                put("label", it.label)
                put("confidence", it.confidence)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }
}