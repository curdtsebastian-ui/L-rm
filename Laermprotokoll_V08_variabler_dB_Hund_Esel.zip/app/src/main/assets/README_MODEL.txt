MODEL DATEI

Lege die YAMNet-TFLite-Datei unter folgendem Namen ab:

    yamnet.tflite

Pfad:
    app/src/main/assets/yamnet.tflite

Die App funktioniert auch ohne diese Datei. Dann bleibt die bisherige
Fallback-Erkennung aktiv.

Für eine echte Eselerkennung benötigen wir zusätzlich eine Esel-spezifische
Klassifikationsschicht bzw. ein entsprechend trainiertes Modell.