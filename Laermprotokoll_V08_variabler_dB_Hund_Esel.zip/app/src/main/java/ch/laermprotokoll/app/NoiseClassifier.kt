package ch.laermprotokoll.app

import android.content.Context
import org.tensorflow.lite.task.audio.classifier.AudioClassifier
import org.tensorflow.lite.support.audio.TensorAudio
import kotlin.math.log10
import kotlin.math.sqrt

object NoiseClassifier {

    enum class Label {
        DONKEY,
        POSSIBLE_DONKEY,
        DOG_BARK,
        DOG_HOWL,
        LOUD_NOISE,
        UNKNOWN
    }

    data class Result(
        val label: Label,
        val confidence: Double,
        val modelAvailable: Boolean,
        val matchingWindows: Int,
        val totalWindows: Int
    )

    private var classifier: AudioClassifier? = null
    private var audio: TensorAudio? = null
    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        try {
            classifier = AudioClassifier.createFromFile(context, "yamnet.tflite")
            audio = classifier?.createInputTensorAudio()
        } catch (_: Exception) {
            classifier = null
            audio = null
        }
    }

    fun classifyEvent(context: Context, samples: ShortArray, sampleRate: Int): Result {
        init(context)
        val windowSize = sampleRate.coerceAtLeast(8000)
        val windows = mutableListOf<ShortArray>()
        var pos = 0
        while (pos < samples.size) {
            val end = minOf(pos + windowSize, samples.size)
            val chunk = samples.copyOfRange(pos, end)
            if (chunk.size >= sampleRate / 2) windows.add(chunk)
            pos = end
        }
        if (windows.isEmpty()) return fallback(samples)

        val counts = mutableMapOf<Label, Int>()
        val scores = mutableMapOf<Label, MutableList<Double>>()
        var modelWindows = 0
        for (window in windows) {
            val r = classifyWindow(context, window, sampleRate)
            if (r.modelAvailable) modelWindows++
            counts[r.label] = (counts[r.label] ?: 0) + 1
            scores.getOrPut(r.label) { mutableListOf() }.add(r.confidence)
        }

        val candidates = listOf(Label.DONKEY, Label.DOG_BARK, Label.DOG_HOWL, Label.POSSIBLE_DONKEY)
        val best = candidates.maxByOrNull { label ->
            val count = counts[label] ?: 0
            val avg = scores[label]?.average() ?: 0.0
            count.toDouble() / windows.size * avg
        }

        if (modelWindows == 0 || best == null) return fallback(samples)
        val count = counts[best] ?: 0
        val avg = scores[best]?.average() ?: 0.0
        val ratio = count.toDouble() / windows.size

        return when {
            best == Label.DONKEY && ratio >= 0.60 && avg >= 0.55 -> Result(Label.DONKEY, avg.coerceAtMost(0.99), true, count, windows.size)
            best == Label.DOG_BARK && ratio >= 0.50 && avg >= 0.45 -> Result(Label.DOG_BARK, avg.coerceAtMost(0.99), true, count, windows.size)
            best == Label.DOG_HOWL && ratio >= 0.50 && avg >= 0.45 -> Result(Label.DOG_HOWL, avg.coerceAtMost(0.99), true, count, windows.size)
            best == Label.POSSIBLE_DONKEY && ratio >= 0.30 -> Result(Label.POSSIBLE_DONKEY, avg.coerceAtMost(0.85), true, count, windows.size)
            else -> Result(Label.LOUD_NOISE, avg.coerceAtMost(0.80), true, count, windows.size)
        }
    }

    private fun classifyWindow(context: Context, samples: ShortArray, sampleRate: Int): Result {
        val c = classifier
        val input = audio
        if (c != null && input != null) {
            try {
                input.load(samples)
                val results = c.classify(input)
                val top = results.flatMap { it.categories }.maxByOrNull { it.score }
                if (top != null) {
                    val name = top.displayName.lowercase(java.util.Locale.ROOT)
                    val score = top.score.toDouble()
                    when {
                        (name.contains("dog") || name.contains("bark")) && score >= 0.35 -> return Result(Label.DOG_BARK, score, true, 1, 1)
                        (name.contains("howl") || name.contains("wolf")) && score >= 0.35 -> return Result(Label.DOG_HOWL, score, true, 1, 1)
                        (name.contains("horse") || name.contains("bray") || name.contains("neigh")) && score >= 0.35 -> return Result(Label.DONKEY, score, true, 1, 1)
                        name.contains("animal") || name.contains("livestock") -> return Result(Label.POSSIBLE_DONKEY, score, true, 1, 1)
                        score >= 0.50 -> return Result(Label.LOUD_NOISE, score, true, 0, 1)
                    }
                }
            } catch (_: Exception) {}
        }
        return fallback(samples)
    }

    private fun fallback(samples: ShortArray): Result {
        if (samples.isEmpty()) return Result(Label.UNKNOWN, 0.0, false, 0, 0)
        var sum = 0.0
        var zeroCrossings = 0
        for (i in samples.indices) {
            val v = samples[i].toDouble()
            sum += v * v
            if (i > 0 && (samples[i - 1] < 0) != (samples[i] < 0)) zeroCrossings++
        }
        val rms = sqrt(sum / samples.size)
        val db = if (rms > 0) 20.0 * log10(rms) else 0.0
        val zcr = zeroCrossings.toDouble() / samples.size
        return if (db > 50.0 && zcr in 0.015..0.20) Result(Label.POSSIBLE_DONKEY, 0.55, false, 1, 1)
        else if (db > 50.0) Result(Label.LOUD_NOISE, 0.80, false, 0, 1)
        else Result(Label.UNKNOWN, 0.20, false, 0, 1)
    }

}
