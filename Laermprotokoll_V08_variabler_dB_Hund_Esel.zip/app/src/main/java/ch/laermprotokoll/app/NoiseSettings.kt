package ch.laermprotokoll.app

import android.content.Context

object NoiseSettings {
    const val MIN_THRESHOLD_DB = 30.0
    const val MAX_THRESHOLD_DB = 90.0
    const val DEFAULT_THRESHOLD_DB = 50.0
    private const val PREFS = "noise_settings"
    private const val THRESHOLD = "threshold_db"

    fun getThreshold(context: Context): Double =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getFloat(THRESHOLD, DEFAULT_THRESHOLD_DB.toFloat())
            .toDouble()
            .coerceIn(MIN_THRESHOLD_DB, MAX_THRESHOLD_DB)

    fun setThreshold(context: Context, value: Double) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putFloat(THRESHOLD, value.coerceIn(MIN_THRESHOLD_DB, MAX_THRESHOLD_DB).toFloat()).apply()
    }
}
