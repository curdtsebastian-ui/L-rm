package ch.laermprotokoll.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import kotlin.math.log10
import kotlin.math.sqrt

class NoiseMonitorService : Service() {

    companion object {
        private const val CHANNEL_ID = "noise_monitor"
        private const val NOTIFICATION_ID = 1001
        private const val THRESHOLD_DB = 50.0
        private const val MIN_DURATION_MS = 2000L
    }

    private var recorder: AudioRecord? = null
    private var running = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, notification())
        if (!running) {
            running = true
            Thread { measureLoop() }.start()
        }
        return START_STICKY
    }

    private fun measureLoop() {
        val sampleRate = 44100
        val minBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBuffer * 2
        )

        val buffer = ShortArray(minBuffer.coerceAtLeast(1024))
        var aboveSince = 0L
        var eventActive = false
        var eventPeak = 0.0
        var sumDb = 0.0
        var samples = 0
        val eventAudio = ArrayList<Short>(sampleRate * 30)

        NoiseClassifier.init(applicationContext)
        recorder?.startRecording()

        while (running) {
            val read = recorder?.read(buffer, 0, buffer.size) ?: 0
            if (read <= 0) continue

            var sum = 0.0
            for (i in 0 until read) {
                val v = buffer[i].toDouble()
                sum += v * v
            }

            val rms = sqrt(sum / read)
            val rawDb = if (rms > 0) 20.0 * log10(rms) else 0.0
            val db = rawDb + NoiseCalibration.getOffset(applicationContext)

            sendBroadcast(Intent("ch.laermprotokoll.LIVE_DB").apply {
                putExtra("db", db)
            })

            val now = System.currentTimeMillis()

            if (db >= THRESHOLD_DB) {
                if (aboveSince == 0L) aboveSince = now

                if (!eventActive && now - aboveSince >= MIN_DURATION_MS) {
                    eventActive = true
                    eventPeak = db
                    sumDb = db
                    samples = 1
                    eventAudio.clear()
                    eventAudio.addAll(buffer.toList())
                } else if (eventActive) {
                    eventPeak = maxOf(eventPeak, db)
                    sumDb += db
                    samples++
                    // Keep at most ~30 seconds per event.
                    if (eventAudio.size < sampleRate * 30) {
                        eventAudio.addAll(buffer.toList())
                    }
                }
            } else {
                if (eventActive) {
                    val average = if (samples > 0) sumDb / samples else 0.0
                    val audioSamples = ShortArray(eventAudio.size)
                    for (i in eventAudio.indices) audioSamples[i] = eventAudio[i]

                    val result = NoiseClassifier.classifyEvent(
                        applicationContext,
                        audioSamples,
                        sampleRate
                    )

                    val label = when (result.label) {
                        NoiseClassifier.Label.DONKEY -> "🫏 Eselruf erkannt"
                        NoiseClassifier.Label.POSSIBLE_DONKEY -> "🫏 Möglicher Eselruf"
                        NoiseClassifier.Label.LOUD_NOISE -> "🔊 Lärm"
                        NoiseClassifier.Label.UNKNOWN -> "❓ Unbekannt"
                    }

                    NoiseEventStore.add(
                        applicationContext,
                        start = aboveSince,
                        end = now,
                        averageDb = average,
                        peakDb = eventPeak,
                        label = label,
                        confidence = result.confidence
                    )
                }
                aboveSince = 0L
                eventActive = false
                eventPeak = 0.0
                sumDb = 0.0
                samples = 0
                eventAudio.clear()
            }
        }

        recorder?.stop()
        recorder?.release()
        recorder = null
    }

    override fun onDestroy() {
        running = false
        recorder?.stop()
        recorder?.release()
        recorder = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Lärmüberwachung",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    private fun notification(): Notification {
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Lärmprotokoll")
                .setContentText("Lärmüberwachung ist aktiv")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("Lärmprotokoll")
                .setContentText("Lärmüberwachung ist aktiv")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        }
    }
}