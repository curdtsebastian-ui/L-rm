package ch.laermprotokoll.app

import android.content.Context

object NoiseCalibration {
    private const val PREFS = "noise_calibration"
    private const val OFFSET = "offset_db"

    fun getOffset(context: Context): Double =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getFloat(OFFSET, 0f).toDouble()

    fun setOffset(context: Context, value: Double) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putFloat(OFFSET, value.toFloat()).apply()
    }
}