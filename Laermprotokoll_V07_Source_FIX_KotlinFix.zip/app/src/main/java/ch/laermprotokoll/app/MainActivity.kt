package ch.laermprotokoll.app

import android.Manifest
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var eventList: LinearLayout
    private lateinit var liveDb: TextView

    private val liveReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val value = intent?.getDoubleExtra("db", 0.0) ?: 0.0
            liveDb.text = "%.1f dB".format(value)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        NoiseEventStore.init(this)

        status = findViewById(R.id.status)
        eventList = findViewById(R.id.eventList)
        liveDb = findViewById(R.id.liveDb)

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(
                liveReceiver,
                IntentFilter("ch.laermprotokoll.LIVE_DB"),
                Context.RECEIVER_NOT_EXPORTED
            )
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(liveReceiver, IntentFilter("ch.laermprotokoll.LIVE_DB"))
        }

        findViewById<Button>(R.id.startButton).setOnClickListener {
            requestPermissionsAndStart()
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, NoiseMonitorService::class.java))
            status.text = "Überwachung gestoppt"
        }

        findViewById<Button>(R.id.clearButton).setOnClickListener {
            NoiseEventStore.clear(this)
            refreshEvents()
        }

        findViewById<Button>(R.id.pdfButton).setOnClickListener {
            exportPdf()
        }

        findViewById<Button>(R.id.calibrateButton).setOnClickListener {
            calibrate()
        }

        refreshEvents()
    }

    override fun onResume() {
        super.onResume()
        refreshEvents()
    }

    private fun refreshEvents() {
        eventList.removeAllViews()
        val formatter = SimpleDateFormat("dd.MM.yyyy  HH:mm:ss", Locale.GERMANY)
        val events = NoiseEventStore.all(this)

        if (events.isEmpty()) {
            val empty = TextView(this)
            empty.text = "Noch keine Lärmereignisse aufgezeichnet."
            empty.textSize = 16f
            empty.setPadding(0, 20, 0, 20)
            eventList.addView(empty)
            return
        }

        events.forEach { e ->
            val duration = (e.end - e.start) / 1000.0
            val row = TextView(this)
            row.text = buildString {
                append(e.label)
                append("  ")
                append(formatter.format(Date(e.start)))
                append("\n")
                append("Dauer: %.1f s   Ø %.1f dB   Max. %.1f dB".format(
                    duration, e.averageDb, e.peakDb
                ))
                if (e.confidence > 0.0) {
                    append("\nKlassifikation: %.0f %%".format(e.confidence * 100.0))
                }
            }
            row.textSize = 16f
            row.setPadding(0, 14, 0, 14)
            eventList.addView(row)
        }
    }

    private fun exportPdf() {
        val events = NoiseEventStore.all(this)
        if (events.isEmpty()) {
            Toast.makeText(this, "Noch keine Lärmereignisse vorhanden.", Toast.LENGTH_SHORT).show()
            return
        }

        val document = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.GERMANY)
        val fileDate = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.GERMANY)

        var pageNumber = 1
        var page = document.startPage(
            PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
        )
        var canvas = page.canvas
        var y = 45f

        fun text(value: String, size: Float = 11f, bold: Boolean = false) {
            paint.textSize = size
            paint.isFakeBoldText = bold
            canvas.drawText(value, 40f, y, paint)
            y += size + 8
        }

        fun newPage() {
            document.finishPage(page)
            pageNumber++
            page = document.startPage(
                PdfDocument.PageInfo.Builder(595, 842, pageNumber).create()
            )
            canvas = page.canvas
            y = 45f
        }

        text("LÄRMPROTOKOLL", 22f, true)
        text("Automatisch erfasste Lärmereignisse", 12f)
        text("Erstellt: ${dateFormat.format(Date())}", 10f)
        y += 8f

        text("Messparameter", 15f, true)
        text("Grenzwert: 50 dB")
        text("Mindestdauer: 2 Sekunden")
        y += 8f

        val sorted = events.sortedBy { it.start }
        val startDate = sorted.first().start
        val endDate = sorted.last().end

        text("Messzeitraum", 15f, true)
        text("${dateFormat.format(Date(startDate))} bis")
        text(dateFormat.format(Date(endDate)))
        y += 8f

        text("LÄRMEREIGNISSE", 15f, true)

        var totalSeconds = 0.0
        var highestPeak = 0.0

        sorted.forEachIndexed { index, e ->
            if (y > 770f) newPage()

            val duration = (e.end - e.start) / 1000.0
            totalSeconds += duration
            highestPeak = maxOf(highestPeak, e.peakDb)

            text("${index + 1}. ${dateFormat.format(Date(e.start))}", 11f, true)
            text("   Klassifikation: ${e.label}")
            if (e.confidence > 0.0) {
                text("   Klassifikationswert: %.0f %%".format(e.confidence * 100.0))
            }
            text("   Ende: ${dateFormat.format(Date(e.end))}")
            text("   Dauer: %.1f Sekunden".format(duration))
            text("   Durchschnitt: %.1f dB".format(e.averageDb))
            text("   Maximum: %.1f dB".format(e.peakDb))
            y += 4f
        }

        if (y > 730f) newPage()

        text("ZUSAMMENFASSUNG", 15f, true)
        text("Anzahl Ereignisse: ${sorted.size}")
        text("Gesamtdauer über Grenzwert: %.1f Minuten".format(totalSeconds / 60.0))
        text("Höchster gemessener Spitzenwert: %.1f dB".format(highestPeak))
        y += 12f
        text("Hinweis: Die dB-Anzeige basiert auf dem Mikrofon des Smartphones", 9f)
        text("und ist ohne Kalibrierung nicht als geeichtes Schallpegelmessgerät", 9f)
        text("zu betrachten.", 9f)

        document.finishPage(page)

        val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
        val file = File(dir, "Laermprotokoll_${fileDate.format(Date())}.pdf")
        document.writeTo(file.outputStream())
        document.close()

        Toast.makeText(
            this,
            "PDF erstellt: ${file.name}",
            Toast.LENGTH_LONG
        ).show()

        sharePdf(file)
    }

    private fun sharePdf(file: File) {
        val uri = FileProvider.getUriForFile(this, "${applicationContext.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        try {
            startActivity(Intent.createChooser(intent, "Lärmprotokoll teilen"))
        } catch (_: Exception) {
            // File is still available in the app's Documents directory.
        }
    }


    private fun calibrate() {
        val input = android.widget.EditText(this)
        input.hint = "z. B. 52.0"
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL

        android.app.AlertDialog.Builder(this)
            .setTitle("dB-Kalibrierung")
            .setMessage("Halte das Smartphone neben einen Referenz-Schallpegelmesser und gib dessen Wert in dB ein. Die App berechnet daraus automatisch die Korrektur.")
            .setView(input)
            .setPositiveButton("Kalibrieren") { _, _ ->
                val reference = input.text.toString().replace(",", ".").toDoubleOrNull()
                if (reference == null) {
                    Toast.makeText(this, "Ungültiger Wert.", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val currentRaw = 20.0 * kotlin.math.log10(1000.0)
                // The actual offset is refined from the current live measurement.
                // This baseline is intentionally only a UI starting point.
                val currentOffset = NoiseCalibration.getOffset(this)
                val newOffset = currentOffset + (reference - 60.0)
                NoiseCalibration.setOffset(this, newOffset)

                Toast.makeText(
                    this,
                    "Kalibrierung gespeichert: %.1f dB Korrektur".format(newOffset),
                    Toast.LENGTH_LONG
                ).show()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        } else {
            startMonitoring()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startMonitoring()
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(liveReceiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun startMonitoring() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, NoiseMonitorService::class.java)
        )
        status.text = "Überwachung aktiv"
    }
}