package ch.laermprotokoll.app

import android.content.Context
import org.tensorflow.lite.task.audio.classifier.AudioClassifier
import org.tensorflow.lite.support.audio.TensorAudio
import kotlin.math.log10
import kotlin.math.sqrt

object NoiseClassifier {

    enum class Label {
        DONKEY,
        POSSIBLE_DONKEY,
        LOUD_NOISE,
        UNKNOWN
    }

    data class Result(
        val label: Label,
        val confidence: Double,
        val modelAvailable: Boolean,
        val donkeyWindows: Int,
        val totalWindows: Int
    )

    private var classifier: AudioClassifier? = null
    private var audio: TensorAudio? = null
    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        try {
            classifier = AudioClassifier.createFromFile(context, "yamnet.tflite")
            audio = classifier?.createInputTensorAudio()
        } catch (_: Exception) {
            classifier = null
            audio = null
        }
    }

    fun classifyEvent(
        context: Context,
        samples: ShortArray,
        sampleRate: Int
    ): Result {
        init(context)

        // Analyze approximately 1-second windows.
        val windowSize = sampleRate.coerceAtLeast(8000)
        val windows = mutableListOf<ShortArray>()

        var pos = 0
        while (pos < samples.size) {
            val end = minOf(pos + windowSize, samples.size)
            val chunk = samples.copyOfRange(pos, end)
            if (chunk.size >= sampleRate / 2) windows.add(chunk)
            pos = end
        }

        if (windows.isEmpty()) {
            return fallback(samples)
        }

        var donkeyScoreSum = 0.0
        var donkeyWindows = 0
        var modelWindows = 0

        for (window in windows) {
            val result = classifyWindow(context, window, sampleRate)
            if (result.modelAvailable) modelWindows++

            if (result.label == Label.DONKEY ||
                result.label == Label.POSSIBLE_DONKEY) {
                donkeyWindows++
                donkeyScoreSum += result.confidence
            }
        }

        val ratio = donkeyWindows.toDouble() / windows.size.toDouble()

        // Strong classification requires repeated evidence across the event.
        return when {
            modelWindows > 0 && ratio >= 0.60 && donkeyScoreSum / donkeyWindows >= 0.55 ->
                Result(
                    Label.DONKEY,
                    (donkeyScoreSum / donkeyWindows).coerceAtMost(0.99),
                    true,
                    donkeyWindows,
                    windows.size
                )

            modelWindows > 0 && ratio >= 0.30 ->
                Result(
                    Label.POSSIBLE_DONKEY,
                    (donkeyScoreSum / maxOf(1, donkeyWindows)).coerceAtMost(0.85),
                    true,
                    donkeyWindows,
                    windows.size
                )

            else -> fallback(samples)
        }
    }

    private fun classifyWindow(
        context: Context,
        samples: ShortArray,
        sampleRate: Int
    ): Result {
        val c = classifier
        val input = audio

        if (c != null && input != null) {
            try {
                input.load(samples)
                val results = c.classify(input)
                val top = results.flatMap { it.categories }
                    .maxByOrNull { it.score }

                if (top != null) {
                    val name = top.displayName.lowercase()
                    val score = top.score.toDouble()

                    val animalLike =
                        name.contains("horse") ||
                        name.contains("animal") ||
                        name.contains("livestock") ||
                        name.contains("bray") ||
                        name.contains("neigh")

                    if (animalLike && score >= 0.35) {
                        return Result(
                            Label.POSSIBLE_DONKEY,
                            score,
                            true,
                            1,
                            1
                        )
                    }

                    if (score >= 0.50) {
                        return Result(Label.LOUD_NOISE, score, true, 0, 1)
                    }
                }
            } catch (_: Exception) {
                // Fallback below.
            }
        }

        return fallback(samples)
    }

    private fun fallback(samples: ShortArray): Result {
        if (samples.isEmpty()) {
            return Result(Label.UNKNOWN, 0.0, false, 0, 0)
        }

        var sum = 0.0
        var zeroCrossings = 0

        for (i in samples.indices) {
            val v = samples[i].toDouble()
            sum += v * v
            if (i > 0 && (samples[i - 1] < 0) != (samples[i] < 0)) {
                zeroCrossings++
            }
        }

        val rms = sqrt(sum / samples.size)
        val db = if (rms > 0) 20.0 * log10(rms) else 0.0
        val zcr = zeroCrossings.toDouble() / samples.size

        return if (db > 55.0 && zcr in 0.015..0.20) {
            Result(Label.POSSIBLE_DONKEY, 0.55, false, 1, 1)
        } else if (db > 50.0) {
            Result(Label.LOUD_NOISE, 0.80, false, 0, 1)
        } else {
            Result(Label.UNKNOWN, 0.20, false, 0, 1)
        }
    }
}