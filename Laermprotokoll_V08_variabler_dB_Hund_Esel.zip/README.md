# Lärmprotokoll

Erste Android-Version der automatisierten Lärmprotokoll-App.

## Aktuelle Einstellungen

- Grenzwert: 50 dB
- Mindestdauer: 2 Sekunden
- Mikrofonmessung über Foreground Service
- Messung läuft auch bei ausgeschaltetem Display weiter, sofern Android den Dienst nicht beendet.
- Lärmereignisse werden mit Start, Ende, Durchschnitt und Peak erfasst.

## Bereits enthalten

- Ereignisliste direkt in der App
- dauerhafte lokale Speicherung der Ereignisse
- Protokoll löschen
- PDF-Export mit Zusammenfassung und Ereignisliste

## Nächste Ausbaustufen

1. Ereignisliste in der App
2. dauerhafte Speicherung (Room)
3. konfigurierbarer Grenzwert
4. konfigurierbare Nachlauf-/Pausenzeit
5. PDF- und CSV-Export
6. Audioaufnahme pro Ereignis
7. Kalibrierung des dB-Wertes
8. automatische Kennzeichnung "Tierlärm / Esel"
9. Tages-, Wochen- und Monatsstatistik
- erste automatische akustische Klassifikation (konservativ)
- Kennzeichnung möglicher Eselrufe im Ereignis und PDF

Hinweis zur Esel-Erkennung:
Die aktuelle Version kennzeichnet nur "möglicher Eselruf" anhand einfacher akustischer Merkmale.
Für eine belastbare Tier-/Eselerkennung sollte im nächsten Schritt ein trainiertes
Audio-Klassifikationsmodell (z. B. TFLite/YAMNet plus Esel-spezifische Feinabstimmung)
integriert werden. Eine solche Klassifikation ist keine beweissichere Identifikation.


## Version 0.6 – Audio-KI-Schnittstelle

- TensorFlow Lite Task Audio eingebunden
- optionale YAMNet-Modellunterstützung
- Modell wird aus `app/src/main/assets/yamnet.tflite` geladen
- App bleibt ohne Modell lauffähig
- YAMNet-Ergebnisse werden konservativ ausgewertet
- nächste Stufe: Esel-spezifisches Modell/Feintuning


## Version 0.7 – Mehrfenster-Klassifikation

Ein Lärmereignis wird jetzt nicht anhand eines einzelnen Audiofensters
klassifiziert. Die App analysiert mehrere ca. 1-Sekunden-Fenster und verlangt
wiederholte Hinweise auf ein Tier-/Esel-ähnliches Geräusch.

- "Eselruf erkannt" bei starker, wiederholter Evidenz
- "Möglicher Eselruf" bei schwächerer Evidenz
- sonst allgemeiner Lärm
- maximal ca. 30 Sekunden Audio pro Ereignis werden intern für die Analyse
  vorgehalten
